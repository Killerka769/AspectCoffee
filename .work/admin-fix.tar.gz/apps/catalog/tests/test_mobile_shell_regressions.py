from pathlib import Path

from django.conf import settings
from django.test import TestCase


class MobileShellRegressionTests(TestCase):
    def test_bottom_navigation_uses_compare_instead_of_duplicate_cart(self):
        response = self.client.get("/")

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'id="mob-nav-compare-badge"')
        self.assertNotContains(response, 'id="mob-nav-cart-badge"')
        self.assertContains(response, "path.startsWith('/catalog/compare')")

    def test_opening_search_closes_mobile_menu(self):
        response = self.client.get("/")

        self.assertContains(
            response,
            'menuOpen = false; searchOpen = true; cartOpen = false; wishlistOpen = false; notifOpen = false;',
        )

    def test_mobile_navigation_is_not_hidden_by_scroll_script(self):
        response = self.client.get("/")
        html = response.content.decode("utf-8")

        behavior_start = html.index("MOBILE APP BEHAVIOR")
        behavior = html[behavior_start:]
        self.assertNotIn("classList.add('nav-hidden')", behavior)
        self.assertNotIn("classList.add('header-scroll-hide')", behavior)

    def test_mobile_header_is_fixed_and_search_has_rounded_offset_frame(self):
        css = (Path(settings.BASE_DIR) / "static/css/mobile_app.css").read_text(
            encoding="utf-8"
        )

        self.assertIn("overflow-x: clip !important", css)
        self.assertIn("FINAL MOBILE SHELL CONTRACT", css)
        self.assertIn("position: fixed !important", css)
        self.assertIn("padding-top: var(--mob-header-h) !important", css)
        self.assertIn("transform: none !important", css)
        self.assertIn("#header .header-search form select", css)
        self.assertIn("display: block !important", css)
        self.assertIn("border-radius: 16px !important", css)
        self.assertIn("top: 8px !important", css)

    def test_search_and_cart_have_backdrop_and_cart_drag_handle(self):
        response = self.client.get("/")

        self.assertContains(response, 'class="mobile-shell-backdrop"')
        self.assertContains(response, "searchOpen || cartOpen")
        self.assertContains(response, 'class="mobile-mini-cart__handle"')
        self.assertContains(response, "cartDragOffset >= 72")
        self.assertContains(response, '@pointermove.window="cartDragMove($event)"')
        self.assertContains(response, "mobile-cart-open")
        self.assertContains(response, 'class="min-h-0 overflow-hidden"')
        self.assertNotContains(
            response,
            "z-[9999] overflow-y-auto max-h-[calc(100vh-80px)]",
        )

    def test_mobile_compare_uses_desktop_sprite_icon(self):
        response = self.client.get("/")

        self.assertContains(response, "#icons--comparison")

    def test_catalog_does_not_render_obsolete_mobile_sort_button(self):
        response = self.client.get("/catalog/")

        self.assertEqual(response.status_code, 200)
        self.assertNotContains(response, 'id="mobile-sort-btn"')
        self.assertContains(response, 'id="mobile-filter-btn"')

    def test_compare_action_uses_one_feedback_and_synchronizes_cards(self):
        js = (Path(settings.BASE_DIR) / "static/asset/js/custom.js").read_text(
            encoding="utf-8"
        )

        self.assertNotIn("showCompareBar", js)
        self.assertNotIn("compare-bar-inner", js)
        storage_index = js.index("localStorage.setItem('compare', JSON.stringify(list));")
        dispatch_index = js.index(
            "document.body.dispatchEvent(new CustomEvent('compareUpdated'",
            storage_index,
        )
        self.assertGreater(dispatch_index, storage_index)
