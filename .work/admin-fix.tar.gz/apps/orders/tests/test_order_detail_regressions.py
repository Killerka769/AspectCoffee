from decimal import Decimal
from unittest.mock import patch

from django.contrib.admin.sites import AdminSite
from django.test import TestCase
from django.urls import reverse

from apps.orders.admin import OrderAdmin
from apps.orders.models import Order
from apps.orders.tasks import create_cdek_waybill
from apps.users.models import User


class OrderDetailRegressionTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            email="order-detail@example.com",
            password="Strongpass1",
        )
        self.order = Order.objects.create(
            user=self.user,
            status=Order.STATUS_COMPLETED,
            delivery_type=Order.DELIVERY_CDEK_DOOR,
            delivery_address={
                "city": "Москва",
                "street": "Новая",
                "house": "1",
                "apartment": "",
            },
            delivery_cost=Decimal("635.00"),
            payment_method=Order.PAYMENT_CARD,
            payment_status=Order.PAYMENT_STATUS_PAID,
            total_amount=Decimal("1006.67"),
            contact_name="Иван Иванов",
            contact_phone="+79013573577",
            contact_email=self.user.email,
            recipient_name="Петр Петров",
            recipient_phone="+79995554433",
        )

    def test_account_detail_shows_actual_recipient_and_reorder_action(self):
        self.client.force_login(self.user)

        response = self.client.get(reverse("users:order_detail", args=[self.order.pk]))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Петр Петров")
        self.assertContains(response, "+79995554433")
        self.assertContains(response, "д. 1")
        self.assertContains(response, "Повторить заказ")
        self.assertContains(response, "не включена в оплату")

    def test_admin_exposes_repeat_order_action(self):
        model_admin = OrderAdmin(Order, AdminSite())
        self.assertIn("repeat_in_customer_cart", model_admin.actions)
        self.assertEqual(model_admin.recipient_display(self.order), "Петр Петров")

    @patch("apps.delivery.cdek.CDEKClient.create_order")
    def test_cdek_waybill_task_is_idempotent(self, create_order):
        self.order.cdek_order_uuid = "7d96f62d-f87d-4dbb-9fa6-1eca1e5a21ed"
        self.order.save(update_fields=["cdek_order_uuid"])

        result = create_cdek_waybill.run(self.order.pk)

        self.assertEqual(result, str(self.order.cdek_order_uuid))
        create_order.assert_not_called()

    @patch("apps.delivery.cdek.CDEKClient.create_order")
    def test_cdek_waybill_task_saves_created_uuid(self, create_order):
        create_order.return_value = {
            "entity": {"uuid": "017fbbda-0cea-4791-80a1-03150af453ea"},
        }

        result = create_cdek_waybill.run(self.order.pk)

        self.order.refresh_from_db()
        self.assertEqual(result, "017fbbda-0cea-4791-80a1-03150af453ea")
        self.assertEqual(str(self.order.cdek_order_uuid), result)
        create_order.assert_called_once()
