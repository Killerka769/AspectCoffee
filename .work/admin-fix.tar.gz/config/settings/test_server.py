"""Settings for the isolated test.aspectcoffee.ru environment."""

from decouple import Csv, config

from .prod import *  # noqa: F403


DEBUG = False
ENVIRONMENT = "test"

ALLOWED_HOSTS = config(
    "ALLOWED_HOSTS",
    default="test.aspectcoffee.ru,localhost,127.0.0.1",
    cast=Csv(),
)
CSRF_TRUSTED_ORIGINS = config(
    "CSRF_TRUSTED_ORIGINS",
    default="https://test.aspectcoffee.ru",
    cast=Csv(),
)
CORS_ALLOWED_ORIGINS = config(
    "CORS_ALLOWED_ORIGINS",
    default="https://test.aspectcoffee.ru",
    cast=Csv(),
)

# Test and production cookies must never overlap in the same browser.
SESSION_COOKIE_NAME = "aspectcoffee_test_sessionid"
CSRF_COOKIE_NAME = "aspectcoffee_test_csrftoken"

# Mail and external services are inert unless test-only credentials are supplied.
EMAIL_BACKEND = config(
    "EMAIL_BACKEND",
    default="django.core.mail.backends.console.EmailBackend",
)
DEFAULT_FROM_EMAIL = config(
    "DEFAULT_FROM_EMAIL",
    default="Aspect Coffee TEST <test@aspectcoffee.ru>",
)

# Do not submit the test subdomain to search engines or preload it separately.
SECURE_HSTS_PRELOAD = False
